import json
import argparse
import logging
import os

logging.basicConfig(level=logging.DEBUG)

def get_result(image):
    logging.info(f'Get result of {image}')
    command = f'anchore-cli --json image vuln {image} all'
    with os.popen(command) as f:
        data = json.load(f)
    # digest = data['imageDigest']
    result = {}
    result['Image'] = image
    metadata = []
    if not 'vulnerabilities' in data:
        return {}, False
    #logging.debug(data['vulnerabilities'])
    for vul in data['vulnerabilities']:
        new_item = {}
        new_item['Vulnerability'] = vul['vuln']
        new_item['Severity'] = vul['severity']
        # anchore没有提供是否修复的fixed字段，只有will_not_fix
        new_item['Fixed'] = 1 if vul['will_not_fix'] == False else 0
        metadata.append(new_item)
    result['Metadata'] = metadata

    return result, True

def del_images(image):
    with os.popen(f'anchore-cli --json image del {image} --force') as f:
        data = f.read()
    logging.info(f'Delete image {image}')

def save_to_file(data, output):
    with open(output, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

def get_all_images():
    logging.info('Get image list')
    with os.popen('anchore-cli --json image list') as f:
        res = f.read()
    try:
        data = json.loads(res)
        images = ['/'.join(image['image_detail'][0]['fulltag'].split('/')[1:]) for image in data]
        return images
    except Exception as e:
        logging.error(e)
        return []
    
# parser = argparse.ArgumentParser()
# parser.add_argument('-i', '--input', help='input file name (image list)')
# parser.add_argument('-o', '--output', help='The output file')

# args = parser.parse_args()

# output = args.output
# input_file = args.input
output = 'result.json'
input_file = 'docker_images.txt'

results = []
with open(output, 'r') as f:
    data = f.read()
results = json.loads(data)

# with open(input_file, 'r') as f:
#     lines = f.readlines()

# lines = [l.strip('\n') for l in lines]

exist_lines = get_all_images()

# diff = set(lines).difference(set(exist_lines))
# print(diff)

# with open('diff.txt', 'w') as f:
#     for i in diff:
#         f.write(i + '\n')
deleting_images = []

for line in exist_lines:
    r, success = get_result(line)
    if success:
        results.append(r)
        deleting_images.append(line)

save_to_file(results, output)
for i in deleting_images:
    del_images(i)

# get_result('wholetale/repo2docker_wholetale:latest')