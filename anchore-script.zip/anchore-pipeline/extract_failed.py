import os
import json

os.popen('export ANCHORE_CLI_USER=admin')
os.popen('export ANCHORE_CLI_PASS=foobar')

def get_all_images():
    failed = []
    with os.popen('anchore-cli --json image list') as f:
        data = f.read()
    data = json.loads(data)
    for d in data:
        if d['analysis_status'] == 'analysis_failed':
            failed.append('/'.join(d['image_detail'][0]['fulltag'].split('/')[1:]))
    return failed

def del_images(image):
    with os.popen(f'anchore-cli --json image del {image} --force') as f:
        data = f.read()
    print(data)
    
failed = get_all_images()

# with open('failed.txt', 'w') as f:
#     for i in failed:
#         f.write(i + '\n')

for f in failed:
    del_images(f)