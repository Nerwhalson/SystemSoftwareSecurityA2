import json

with open('result.json', 'r') as f:
    data = f.read()
data = json.loads(data)
print(len(data))