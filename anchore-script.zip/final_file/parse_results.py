import json
import os
import re


def read_and_parse_json(file_path):
    if not os.path.getsize(file_path):
        return
    with open(file_path, 'r') as file:
        data = json.load(file)
    result = {}
    result['Image'] = data['source']['target']['userInput']
    metadata = []
    #logging.debug(data['vulnerabilities'])
    for vul in data['matches']:
        try:
            new_item = {}
            new_item['Vulnerability'] = vul['vulnerability']['id']
            new_item['Severity'] =  vul['vulnerability']['severity']
            # anchore没有提供是否修复的fixed字段，只有will_not_fix
            
            new_item['Fixed'] = 1 if vul['vulnerability']['fix']['state'] == 'fixed' else 0

            metadata.append(new_item)
        except:
            pass

    result['Metadata'] = metadata

    return result 

def combine_json_files(directory):
    combined_data = []
    for filename in os.listdir(directory):
        if filename.endswith('.json'):
            file_path = os.path.join(directory, filename)
            info = read_and_parse_json(file_path)
            if not info:
                continue
            combined_data.append(info)
    return combined_data

def write_json_file(data, file_path):
    with open(file_path, 'w') as file:
        json.dump(data, file, indent=4)

directory = 'output/'

combined_data = combine_json_files(directory)

new_file_path = 'combined_data.json'

write_json_file(combined_data, new_file_path)
