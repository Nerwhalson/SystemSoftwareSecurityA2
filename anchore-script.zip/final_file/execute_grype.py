import os
import time
import logging
import subprocess
import argparse
from tqdm import tqdm

logging.basicConfig(level=logging.INFO)

def delete_docker_images(batch_images):
    for image in batch_images:
        try:
            subprocess.run(f"docker rmi -f {image}", shell=True, check=True)
            logging.info(f"Docker image {image} has been deleted.")
        except subprocess.CalledProcessError as e:
            logging.error(f"An error occurred while deleting image {image}: {e}")

def delete_tmp():
    try:
        # Delete all Docker images
        subprocess.run(["sudo rm -rf /tmp/*"], check=True, shell=True)
        logging.info("All tmp file have been deleted.")
    except subprocess.CalledProcessError as e:
        logging.error(f"An error occurred: {e}")

def run_grype(image, output_dir, timeout=5*60):
    command = f'grype docker:{image} -o json > {output_dir}result_{image.replace("/", "_")}.json'
    # try:
    #     os.system()
    # except Exception as e:
    #     logging.error(f'Analyzing {e} failed')

    try:
        result = subprocess.run(command, shell=True, timeout=timeout, capture_output=True)
        return result.returncode == 0
    except subprocess.TimeoutExpired:
        logging.error(f"Command '{command}' timed out")
        return False
    except Exception as e:
        logging.error(f"Error executing command '{command}': {e}")
        return False
    


parser = argparse.ArgumentParser()
parser.add_argument('-i', '--input', help='input file name (image list)')
parser.add_argument('-s', '--start', help='start from')
parser.add_argument('-e', '--end', help='end at')
parser.add_argument('-b', '--batch', help='batch size')
parser.add_argument('-runtime_file', '--runtime_file', help='runtime file name')


start_time = time.time()

args = parser.parse_args()

batch_size = int(args.batch)

start = int(args.start)
end = int(args.end)

if end < start + batch_size:
    logging.error('End position cannot less than start + batch size')

with open(args.input) as f:
    images = f.readlines()

for i in range(start, end, batch_size):
    logging.info(f'Start batch {i} - {i + batch_size}')
    start_time = time.time()
    batch_image = []
    for image in tqdm(images[i: i + batch_size]):
        # logging.info(f'{index}/{batch_size}')
        image = image.strip('\n')
        run_grype(image, 'output/')
        batch_image.append(image)
    elapsed_time = time.time() - start_time
    logging.info(f'Runtime of batch {i} - {i+batch_size}: {elapsed_time}')
    with open(args.runtime_file, 'a+') as f:
        f.write(str(elapsed_time) + '\n')
    delete_docker_images(batch_image)
    # delete_tmp()
logging.info("Finished")
