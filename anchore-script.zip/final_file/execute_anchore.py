import os
import sys
import json
import argparse
import time
import logging
import asyncio

logging.basicConfig(level=logging.DEBUG)

os.system('export ANCHORE_CLI_USER=admin')
os.system('export ANCHORE_CLI_PASS=foobar')

def check_status():
    logging.info('Checking status of anchore')
    f = os.popen('anchore-cli --json account whoami')
    try:
        data = json.load(f)
        f.close()
        if data['account']:
            return True
        else:
            return False
    except Exception as e:
        logging.error(f'{e}, checking status failed')
        f.close()
        return False

def is_image_exist(image):
    logging.info('Check if this image has been added already')
    if image in current_images:
        return True
    else:
        return False

def add_image(image):
    logging.info(f'Add image: {image}')
    if is_image_exist(image):
        return True
    with os.popen(f'anchore-cli --json image add {image}') as f:
        data = f.read()
    try:
        data = json.loads(data)
        if data[0]['analysis_status']:
            logging.debug('add image success')
        else:
            logging.debug('add image failed')
            return False
    except:
        logging.error(f'Failed to add image: {image}')
        return False
    return True

async def get_status_of_image(image, semaphore):
    logging.info(f'Get status of {image}')
    async with semaphore:
        with os.popen(f'anchore-cli --json image wait {image}') as f:
            raw_data = f.read()
        try:
            data = json.loads(raw_data)
            logging.info(f'Analysis for {image} finished')
            if data[0]['analysis_status'] == 'analysis_failed':
                return False
            elif data[0]['analysis_failed'] == 'analyzed':
                return True
        except json.JSONDecodeError as e:
            logging.error(e)

        return False

async def monitor_analyse_status(images, max_concurrent_tasks=50):
    semaphore = asyncio.Semaphore(max_concurrent_tasks)
    tasks = [get_status_of_image(image, semaphore) for image in images]
    results = await asyncio.gather(*tasks)
    true_count = results.count(True)
    false_count = results.count(False)
    return true_count, false_count

def get_all_images():
    logging.info('Get image list')
    with os.popen('anchore-cli --json image list') as f:
        res = f.read()
    try:
        data = json.loads(res)
        images = ['/'.join(image['image_detail'][0]['fulltag'].split('/')[1:]) for image in data]
        return images
    except Exception as e:
        logging.error(e)
        return []
        
parser = argparse.ArgumentParser()
parser.add_argument('-i', '--input', help='input file name (image list)')
# parser.add_argument('-o', '--output', help='The output file')

start_time = time.time()

args = parser.parse_args()

fail = 0

# output = args.output
input_file = args.input

results = []
images = []

current_images = set()

if not check_status():
    sys.exit(1)

# get all images
for image in get_all_images():
    current_images.add(image)

with open(input_file, 'r') as f:
    lines = f.readlines()

# add all images first
for image in lines:
    image = image.strip('\n')
    images.append(image)
    logging.info(f'Processing {image}...')
    if not add_image(image):
        fail += 1
        continue

logging.info(f'Added all images, spent {time.time() - start_time}')

start_time_2 = time.time()

true_count, false_count = asyncio.run(monitor_analyse_status(images))

#save_to_file(results, output)

logging.info(f'Successfully analyse {true_count} images, {false_count + fail} images failed, spent {time.time() - start_time_2}')

