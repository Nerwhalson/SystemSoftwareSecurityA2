# Anchore

- `execute_anchore.py` Script for legacy version of Anchore engine(Deprecated)
- `execute_grype.py` Script for running grype  
- `parse_results.py` Parse results from original grype output to the unified format

## Usage

```python
python3 execute_grype.py -i DOCKER_IMAGE_LIST_FILE -s START_INDEX -e END_INDEX -b BATCH_SIZE -runtime_file FILE_FOR_RECORDING_RUNTIME
```
